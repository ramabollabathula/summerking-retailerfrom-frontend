import RetailerForm from "@/components/RetailerForm";

const Index = () => {
  return <RetailerForm />;
};

export default Index;
