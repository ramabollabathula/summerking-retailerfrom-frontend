//export const API_URLS = "http://localhost:5000";
// export const API_URLS = "http://31.97.233.138:5000";
export const API_URLS = "https://retailersform.summerkingindia.com:5000";