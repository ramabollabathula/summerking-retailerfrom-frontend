import React from "react";

interface FormCardProps {
  hindiLabel: string;
  englishLabel: string;
  required?: boolean;
  inputType?: "short" | "long" | "file";
  placeholder?: string;
  name: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  onFileChange?: (file: File) => void;
  error?: string; // New prop for error message
}

const FormCard: React.FC<FormCardProps> = ({
  hindiLabel,
  englishLabel,
  required = false,
  inputType = "short",
  placeholder,
  name,
  value,
  onChange,
  onFileChange,
  error
}) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && onFileChange) {
      onFileChange(e.target.files[0]);
    }
  };

  return (
    <div className="form-card p-3 p-md-4 mb-3" style={{
      border: error ? '1px solid #dc3545' : '1px solid #dee2e6',
      borderRadius: '8px',
      backgroundColor: '#fff'
    }}>
      <div className="mb-1">
        <span className="form-label-hindi">
          {hindiLabel} {required && <span className="form-required">*</span>}
        </span>
      </div>
      <div className="mb-2">
        <span className="form-label-english">{englishLabel}</span>
      </div>

      {inputType === "file" ? (
        <div>
          <input
            type="file"
            className={`form-control ${error ? 'is-invalid' : ''}`}
            onChange={handleFileChange}
            accept="image/*"
            style={{
              borderColor: error ? '#dc3545' : '',
              boxShadow: error ? '0 0 0 0.25rem rgba(220, 53, 69, 0.25)' : 'none'
            }}
          />
        </div>
      ) : inputType === "long" ? (
        <div>
          <textarea
            className={`form-control ${error ? 'is-invalid' : ''}`}
            name={name}
            value={value}
            placeholder={placeholder}
            onChange={onChange}
            rows={3}
            style={{
              borderColor: error ? '#dc3545' : '',
              boxShadow: error ? '0 0 0 0.25rem rgba(220, 53, 69, 0.25)' : 'none'
            }}
          />
        </div>
      ) : (
        <div>
          <input
            type="text"
            className={`form-control ${error ? 'is-invalid' : ''}`}
            name={name}
            value={value}
            placeholder={placeholder}
            onChange={onChange}
            style={{
              borderColor: error ? '#dc3545' : '',
              boxShadow: error ? '0 0 0 0.25rem rgba(220, 53, 69, 0.25)' : 'none'
            }}
          />
        </div>
      )}

      {/* Error message below the input field */}
      {error && (
        <div className="text-danger mt-2" style={{
          fontSize: '12px',
          display: 'flex',
          alignItems: 'center',
          gap: '4px'
        }}>
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16">
            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
            <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
          </svg>
          <span>{error}</span>
        </div>
      )}
    </div>
  );
};

export default FormCard;