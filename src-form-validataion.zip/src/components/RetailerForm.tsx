import React, { useState, useEffect, useRef } from "react";
import FormHeader from "./FormHeader";
import FormCard from "./FormCard";
import { API_URLS } from "./Apiurls/Apiurls";

const RetailerForm: React.FC = () => {
  const [form, setForm] = useState({
    distributor_name: "",
    location: "",
    salesman_name: "",
    shop_name: "",
    shop_address: "",
    contact_person: "",
    contact_mobile: "",
    shop_age: "",
    google_map_link: ""
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [photo, setPhoto] = useState<File | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 🔒 Mobile Only Check
  const [isMobile, setIsMobile] = useState(true);
  
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    const checkDevice = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    checkDevice();
    window.addEventListener("resize", checkDevice);
    return () => window.removeEventListener("resize", checkDevice);
  }, []);

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  // Validation functions
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    // Required field validations
    if (!form.distributor_name.trim()) {
      newErrors.distributor_name = "Distributor name is required";
    }

    if (!form.location.trim()) {
      newErrors.location = "Location is required";
    }

    if (!form.shop_name.trim()) {
      newErrors.shop_name = "Shop name is required";
    }

    if (!form.shop_address.trim()) {
      newErrors.shop_address = "Shop address is required";
    }

    if (!form.contact_person.trim()) {
      newErrors.contact_person = "Contact person name is required";
    }

    // Mobile number validation
    const mobileRegex = /^[0-9]{10}$/;
    if (!form.contact_mobile.trim()) {
      newErrors.contact_mobile = "Mobile number is required";
    } else if (!mobileRegex.test(form.contact_mobile.replace(/\s/g, ''))) {
      newErrors.contact_mobile = "Please enter a valid 10-digit mobile number";
    }
 if (!form.shop_age.trim()) {
      newErrors.shop_age = "Shop age is required";
    }


    // Photo validation
    if (!photo) {
      newErrors.shop_photo = "Shop photo is required";
    }

    // Google Map link validation
    if (!form.google_map_link.trim()) {
      newErrors.google_map_link = "Google Map location is required";
    } else if (!form.google_map_link.includes("google.com/maps") && 
               !form.google_map_link.includes("maps.google.com") &&
               !form.google_map_link.includes("maps.app.goo.gl")) {
      newErrors.google_map_link = "Please enter a valid Google Maps link";
    }

    setErrors(newErrors);
    
    // Scroll to first error if any
    if (Object.keys(newErrors).length > 0 && formRef.current) {
      const firstErrorField = Object.keys(newErrors)[0];
      const errorElement = formRef.current.querySelector(`[name="${firstErrorField}"]`);
      if (errorElement) {
        errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        (errorElement as HTMLElement).focus();
      }
    }
    
    return Object.keys(newErrors).length === 0;
  };

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation not supported");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const link = `https://www.google.com/maps?q=${lat},${lng}`;

        setForm((prev) => ({
          ...prev,
          google_map_link: link
        }));
        
        // Clear any existing error for google_map_link
        if (errors.google_map_link) {
          setErrors(prev => {
            const newErrors = { ...prev };
            delete newErrors.google_map_link;
            return newErrors;
          });
        }
      },
      () => {
        alert("Location permission denied");
      },
      { enableHighAccuracy: true }
    );
  };

  const clearForm = () => {
    setForm({
      distributor_name: "",
      location: "",
      salesman_name: "",
      shop_name: "",
      shop_address: "",
      contact_person: "",
      contact_mobile: "",
      shop_age: "",
      google_map_link: ""
    });
    setPhoto(null);
    setErrors({});
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate all fields
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const data = new FormData();
      Object.entries(form).forEach(([key, value]) => {
        data.append(key, value);
      });
      if (photo) data.append("shop_photo", photo);

      const res = await fetch(`${API_URLS}/api/retailers`, {
        method: "POST",
        body: data
      });

      const json = await res.json();

      if (res.ok) {
        setShowModal(true);
        clearForm();
      } else {
        alert(json.message || "Error submitting form");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while submitting the form");
    } finally {
      setIsSubmitting(false);
    }
  };

  const closeModal = () => {
    setShowModal(false);
  };

  // 🚫 Desktop Block
  if (!isMobile) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-6 rounded shadow text-center max-w-md">
          <h3 className="text-xl font-semibold mb-2">Mobile Access Only</h3>
          <p className="text-gray-600">
            This form is available only on mobile devices.
            <br />
            Please open this link on your smartphone.
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      <form ref={formRef} onSubmit={handleSubmit} className="form-page-bg py-4">
        <div className="container-fluid px-2 px-sm-3">
          <div className="row justify-content-center">
            <div className="col-12 col-md-10 col-lg-8 col-xl-7">
              <FormHeader />

              <FormCard 
                hindiLabel="डिस्ट्रिब्यूटर का नाम" 
                englishLabel="Distributor name" 
                required 
                name="distributor_name" 
                value={form.distributor_name} 
                onChange={handleChange}
                error={errors.distributor_name}
              />
              
              <FormCard 
                hindiLabel="लोकेशन / शहर / मार्केट" 
                englishLabel="Location/ city/market" 
                required 
                name="location" 
                value={form.location} 
                onChange={handleChange}
                error={errors.location}
              />
              
              <FormCard 
                hindiLabel="सेल्समैन" 
                englishLabel="Salesman name" 
                name="salesman_name" 
                value={form.salesman_name} 
                onChange={handleChange}
              />
              
              <FormCard 
                hindiLabel="रिटेल शॉप का नाम" 
                englishLabel="Retail shop name" 
                required 
                name="shop_name" 
                value={form.shop_name} 
                onChange={handleChange}
                error={errors.shop_name}
              />
              
              <FormCard 
                hindiLabel="रिटेल शॉप का पूरा पता / पिन कोड" 
                englishLabel="Full retail shop address / pin code" 
                inputType="long" 
                name="shop_address" 
                value={form.shop_address} 
                onChange={handleChange}
                error={errors.shop_address}
              />
              
              <FormCard 
                hindiLabel="संपर्क व्यक्ति का नाम" 
                englishLabel="Contact person name" 
                required
                name="contact_person" 
                value={form.contact_person} 
                onChange={handleChange}
                error={errors.contact_person}
              />
              
              <FormCard 
                hindiLabel="संपर्क व्यक्ति का मोबाइल नंबर" 
                englishLabel="Contact person mobile number" 
                required
                name="contact_mobile" 
                value={form.contact_mobile} 
                onChange={handleChange}
                error={errors.contact_mobile}
              />
              
              <FormCard 
                hindiLabel="दुकान कितने साल पुरानी है (वर्षों में)" 
                englishLabel="Shop age (in years)" 
                required
                name="shop_age" 
                value={form.shop_age} 
                onChange={handleChange}
                error={errors.shop_age}
              />

              <FormCard
                key={photo ? "with-photo" : "no-photo"}
                hindiLabel="दुकान की फोटो अपलोड करे"
                englishLabel="Upload shop photo"
                inputType="file"
                name="shop_photo"
                required
                onFileChange={(file) => {
                  setPhoto(file);
                  if (errors.shop_photo) {
                    setErrors(prev => {
                      const newErrors = { ...prev };
                      delete newErrors.shop_photo;
                      return newErrors;
                    });
                  }
                }}
                error={errors.shop_photo}
              />

              <div style={{ position: "relative" }}>
                <FormCard
                  hindiLabel="Google Map लोकेशन की लिंक अपलोड करें"
                  englishLabel="Upload google map location link"
                  inputType="long"
                  required
                  name="google_map_link"
                  value={form.google_map_link}
                  onChange={handleChange}
                  error={errors.google_map_link}
                />

                <span
                  onClick={getCurrentLocation}
                  style={{
                    position: "absolute",
                    right: "20px",
                    bottom: errors.google_map_link ? "60px" : "28px",
                    cursor: "pointer",
                    fontSize: "30px",
                    userSelect: "none",
                    zIndex: 1
                  }}
                  title="Get current location"
                >
                  📍
                </span>
              </div>

              {/* Show validation errors summary */}
              {Object.keys(errors).length > 0 && (
                <div className="alert alert-danger mt-3">
                  <strong>Please fix the following errors:</strong>
                  <ul className="mb-0 mt-2">
                    {Object.entries(errors).map(([field, message]) => (
                      <li key={field}>{message}</li>
                    ))}
                  </ul>
                </div>
              )}

              <button
                type="submit"
                className="btn btn-primary w-100 mt-4"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    Submitting...
                  </>
                ) : (
                  "Submit Form"
                )}
              </button>
            </div>
          </div>
        </div>
      </form>

      {showModal && (
        <div className="modal show d-block" style={{ backgroundColor: "rgba(0,0,0,0.5)" }} tabIndex={-1}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header border-0">
                <h5 className="modal-title">Success</h5>
                <button type="button" className="btn-close" onClick={closeModal}></button>
              </div>
              <div className="modal-body text-center">
                <h4 className="mb-3">Thank You!</h4>
                <p>Your form has been submitted successfully.</p>
              </div>
              <div className="modal-footer border-0 justify-content-center">
                <button type="button" className="btn btn-primary" onClick={closeModal}>
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default RetailerForm;